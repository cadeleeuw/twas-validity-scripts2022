library(viridis)

numstr = function(x, add.comma=T) {format(x, scientific=F, trim=T, big.mark=ifelse(add.comma, ",", ""))}



### Figure 1 ###

dat = read.table("data/figure1.dat", header=T)

h2.expr.range = sort(unique(dat$h2.expr))
h2.pheno.range = sort(unique(dat$h2.pheno))


png("figure1.png", 300, 240, unit="mm", res=300, type="cairo")
par(mfrow=c(2,2), cex.axis=1.05, cex.lab=1.4, cex.main=1.4)

y.lim = c(0, ceiling(max(dat$error05)*10)/10) #round up to nearest multiple of 0.1
color = viridis(3) #color.range("red", 3)

for (N.expr in c(250, 1000)) {
	for (N.pheno in c(10000, 100000)) {
		curr = dat[dat$N.expr == N.expr & dat$N.pheno == N.pheno,]
		plot(log10(h2.pheno.range), curr$error05[curr$h2.expr==h2.expr.range[1]], type="b", pch=19, col=color[1], lwd=2, xaxt="n", ylim=y.lim,
      xlab="Outcome h2 (%)", ylab="Type 1 error rate", main=paste0("Expression N = ", numstr(N.expr), ", outcome N = ", numstr(N.pheno)))
		for (i in 2:3) points(log10(h2.pheno.range), curr$error05[curr$h2.expr==h2.expr.range[i]], type="b", pch=19, col=color[i], lwd=2)
		axis(1, at=log10(h2.pheno.range), labels=h2.pheno.range)
		legend("topleft", legend=h2.expr.range, title="Expression h2 (%)", lwd=2, pch=19, col=color, cex=1.2)
	  abline(h=0.05, lwd=2, lty=2, col="grey")
	}
}
dev.off()



### Figure 2 ###

dat = read.table("data/figure2.dat", header=T)


h2.pheno.range = sort(unique(dat$h2.pheno))

png("figure2.png", 300, 120, unit="mm", res=300, type="cairo")
par(mfrow=c(1,2), cex.axis=1.2, cex.lab=1.4, cex.main=1.4)

color = viridis(3) 

thresh.col = c("infl05", "infl01", "infl001")
thresh = c(0.05, 0.01, 0.001)

for (N.pheno in c(10000, 100000)) {
  curr = dat[dat$N.pheno == N.pheno,]
  y.lim = c(0, ifelse(N.pheno == 10000, 13, 240))
  plot(log10(h2.pheno.range), curr[[thresh.col[1]]], type="b", pch=19, col=color[1], lwd=2, xaxt="n", ylim=y.lim,
       xlab="Outcome h2 (%)", ylab="Type 1 error rate inflation", main=paste0("Outcome N = ", numstr(N.pheno)))
  for (i in 2:3) points(log10(h2.pheno.range), curr[[thresh.col[i]]], type="b", pch=19, col=color[i], lwd=2)
  axis(1, at=log10(h2.pheno.range), labels=h2.pheno.range)
  legend("topleft", legend=thresh, title="Alpha", lwd=2, pch=19, col=color, cex=1.2)
  abline(h=1, lwd=2, lty=2, col="grey")
}
dev.off()



### Figure 3 ###

methods = c("lava.rg", "lava.twas", paste0("fusion.", c("blup", "bslmm", "enet", "lasso")))
method.names = c("LAVA-rG", "LAVA-TWAS", "FUSION-BLUP", "FUSION-BSLMM", "FUSION-ElastNet", "FUSION-LASSO")
fusion.names = c("BLUP", "Bayesian LMM", "Elastic Net", "LASSO")

info.col = c("N.expr", "h2.expr", "h2.pheno")
col.offset = length(info.col)

res = read.table("data/figure3-lava.dat", header=T, stringsAsFactors=F)
names(res)[col.offset + 1:2] = methods[1:2]

for (method in methods[-(1:2)]) {
  curr = read.table(paste0("data/figure3-", gsub("\\.", "-", method), ".dat"), header=T)
  names(curr)[col.offset+1] = method
  res = merge(res, curr, by=info.col)
}
res = res[order(res$N.expr, res$h2.expr, res$h2.pheno),]


h2.expr.range = sort(unique(res$h2.expr))
h2.pheno.range = sort(unique(res$h2.pheno))

png("figure3.png", 300, 120, unit="mm", res=300, type="cairo")
par(mfrow=c(1,2), cex.axis=0.8, cex.lab=1.4, cex.main=1.4)

y.lim = c(0, ceiling(max(res[,methods])*10)/10) #round up to nearest multiple of 0.1
color = viridis(6) 
line.type = rep(c(1,3), each=3)
point.type = rep(c(19,17, 15), times=2)

for (h2.expr in c(1, 10)) {
  curr = res[res$h2.expr == h2.expr,]
  plot(log10(h2.pheno.range), curr[[methods[1]]], type="b", pch=point.type[1], col=color[1], lwd=2, lty=line.type[1], xaxt="n", ylim=y.lim,
       xlab="Outcome h2 (%)", ylab="Type 1 error rate", main=paste0("Expression h2 = ", h2.expr, "%"))
  for (i in 2:length(methods)) points(log10(h2.pheno.range), curr[[methods[i]]], type="b", pch=point.type[i], col=color[i], lwd=2, lty=line.type[i])
  axis(1, at=log10(h2.pheno.range), labels=h2.pheno.range)
  legend("topleft", legend=method.names, title="Method", lwd=2, pch=point.type, col=color, cex=1, lty=line.type)
  abline(h=0.05, lwd=2, lty=2, col="grey")
}
dev.off()



### Figure 4 ###

dat = read.table("data/figure4.dat", header=T, stringsAsFactors=F)

get.pshift = function(scaled.se, ref.p) {stat = qnorm(ref.p/2); pval = pnorm(stat, sd=scaled.se)*2; return(pval)}


png("figure4.png", 300, 150, unit="mm", res=300, type="cairo")
par(mfrow=c(1,2), cex.axis=1, cex.lab=1.3, mar=c(5,4,4,7)+0.1)

logp = -log10(dat[,c("shift.p05", "shift.p0001")])
logp.trans = lm(logp$shift.p05~logp$shift.p0001)$coefficients

ticks.left = c(0.05, 0.01, 0.001, 1e-4, 1e-5)
tick.values.left = -log10(ticks.left)

ticks.right = 10^-seq(4, 16, by=3)
tick.values.right = logp.trans[1] + logp.trans[2] * -log10(ticks.right)

plot(dat$se.ratio, -log10(dat$shift.p05), pch=19, ylim=range(tick.values.left), yaxt="n", xlab="Standard error deflation", ylab="Output p-value, reference = 0.05")
axis(2, at=tick.values.left, labels=ticks.left)
axis(4, at=tick.values.right, labels=ticks.right)
mtext("Output p-value, reference = 1e-04", side=4, line=3, cex=1.4)

qq = quantile(dat$se.ratio, c(0.05, 0.25, 0.5, 0.75, 0.95))
qq.pshift = get.pshift(qq, 0.05)
size = rep(1.25, 5); size[3] = 2.5
points(qq, -log10(qq.pshift), pch=19, cex=size, col="red")
abline(h=-log10(0.05), lwd=2, lty=2, col="grey")


ref.logp = seq(0, 5, length.out=10000)
z = qnorm(0.5*10^(-ref.logp))
logp = -log10(pnorm(z, sd=1)*2)
for (i in 5:1) logp = cbind(logp, -log10(pnorm(z, sd=qq[i])*2))
color = viridis(6) #c("black", rgb(1, 0:4/5, 0:4/5))
color[1] = "black"

plot(ref.logp, logp[,1], type="l", col=color[1], lwd=2, xaxt="n", yaxt="n", ylim=c(0,9), xlab="Reference p-value", ylab="Output p-value")
for (i in 1:5) points(ref.logp, logp[,i+1], type="l", lwd=2, col=color[i+1])

ticks.x = c(0.5, 0.05, 10^-(2:5))
axis(1, at=-log10(ticks.x), labels=ticks.x)

ticks.y = c(0.5, 0.05, 10^-c(3,5,7,9))
axis(2, at=-log10(ticks.y), labels=ticks.y)

legend("topleft", title="Standard error deflation", legend=c("None", "95th percentile", "75th percentile", "Median", "25th percentile", "5th percentile"),lwd=2, col=color, cex=1)
dev.off()



