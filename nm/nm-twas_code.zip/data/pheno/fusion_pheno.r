phenos = c("bp", "bmi", "ea", "scz", "diabetes")

for (p in phenos) {
	out.file = paste0(p, "_fusion.stats")
	if (!file.exists(out.file)) {
		dat = read.table(paste0(p, "_filt.pval"), header=T, stringsAsFactors=F)
		if ("BETA" %in% names(dat)) dir = sign(dat$BETA)
		if ("OR" %in% names(dat)) dir = sign(log(dat$OR))
		dat$Z = abs(qnorm(dat$P/2)) * dir
		dat = dat[,c("SNP", "A1", "A2", "Z")]
		write.table(dat, file=out.file, row.names=F, quote=F, sep="\t")
	}
}
